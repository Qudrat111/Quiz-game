import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutterlesson7/Counter.dart';
import 'package:flutterlesson7/JAVA/MyResult1.dart';
import 'package:flutterlesson7/Text.dart';
import '../Button.dart';
int counter = 0;
int questionIndex = 0;

class QuizQuestion {
  String question;
  List<String> answerChoices;
  String correctAnswer;

  QuizQuestion({
    required this.question,
    required this.answerChoices,
    required this.correctAnswer,
  });
}

List<QuizQuestion> quizQuestions = [
  QuizQuestion(
      question: "What is the main purpose of the public static void main(String[] args) method in a Java program?",
      answerChoices: [
        "To declare variables",
        "To define class attributes",
        "To specify command-line arguments",
        "To execute the program"],
      correctAnswer: "To execute the program"
  ),

  QuizQuestion(
      question: "In Java, which keyword is used to create a subclass that inherits properties and behaviors from a superclass?",
      answerChoices: ["implement","extends","override", "abstract"],
      correctAnswer: "extends"
  ),

  QuizQuestion(
      question: "What is the Java keyword used to explicitly allocate memory for an object?",
      answerChoices: ["new", "malloc", "create", "allocate"],
      correctAnswer: "new"
  ),

  QuizQuestion(
      question: "Which data type in Java is used to represent whole numbers without a decimal point?",
      answerChoices: ["float","double","int","char"],
      correctAnswer: "int"
  ),

  QuizQuestion(
      question: "In Java, what is the purpose of the break statement within a loop?",
      answerChoices: [
        "It ends the program",
        "It skips the current iteration of the loop",
        "It terminates the loop and continues with the next iteration",
        "It resumes execution at the beginning of the loop"],
      correctAnswer:   "It skips the current iteration of the loop"
  ),

  QuizQuestion(
      question: "Which collection framework interface in Java allows you to store elements in a key-value?",
      answerChoices: [
        "ArrayList",
        "HashSet",
        "HashMap",
        "LinkedList"],
      correctAnswer: "HashMap"
  ),

  QuizQuestion(
      question: "What is the access modifier that allows a variable or method to be accessible within the same class and its subclasses, but not outside the class or package?",
      answerChoices: [
        "private",
        "protected",
        "public",
        "static"],
      correctAnswer:  "protected"
  ),

  QuizQuestion(
      question: "Which Java keyword is used to handle exceptions in a try-catch block?",
      answerChoices: [
        "handle",
        "throw",
        "catch",
        "throws"],
      correctAnswer: "catch"
  ),

  QuizQuestion(
      question: "What is the process of converting an object of a class to its byte stream representation in Java?",
      answerChoices: [
        "Serialization",
        "Deserialization",
        "Objectification",
        "Bytecasting"],
      correctAnswer: "Serialization"
  ),
  QuizQuestion(
      question: "Which Java keyword is used to define a constant value that cannot be changed after initialization?",
      answerChoices: [
        "final",
        "static",
        "constant",
        "immutable"],
      correctAnswer: "final"
  ),

];

class My_Savollar_Logikasi_Java extends StatelessWidget{
  const My_Savollar_Logikasi_Java({super.key});
  @override
  Widget build(BuildContext context) {
    Timer myTimer = Timer(const Duration(seconds: 20), (){
      Navigator.push(context,MaterialPageRoute(builder: (context) =>  const My_Savollar_Logikasi_Java()));
      });
    Random random = Random();
    QuizQuestion quizQuestion = quizQuestions[random.nextInt(quizQuestions.length)];
    quizQuestions.remove(quizQuestion);
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        children:[
          MyText(text: "Savol ${++questionIndex} :${quizQuestion.question}", size: 30.0,color: Colors.blue),
          const SizedBox(height: 40,),
          MyButton(satr: quizQuestion.answerChoices[0],click: (){
            if(quizQuestions.isNotEmpty) {
             if (quizQuestion.answerChoices[0] == quizQuestion.correctAnswer) counter++;
             myTimer.cancel();
            Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_Java()));
          }else {
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_1()));}
          }),
         const SizedBox(height: 30,),
          MyButton(satr: quizQuestion.answerChoices[1], click:(){
            if(quizQuestions.isNotEmpty) {
            if (quizQuestion.answerChoices[1] == quizQuestion.correctAnswer) counter++;
            myTimer.cancel();
            Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Savollar_Logikasi_Java()));
          }else {
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_1()));}
          }),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion.answerChoices[2],click:(){
            if(quizQuestions.isNotEmpty) {
              if (quizQuestion.answerChoices[2] == quizQuestion.correctAnswer) counter++;
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_Java()));
            }else {
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_1()));}
          },),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion.answerChoices[3],click: (){
            if(quizQuestions.isNotEmpty) {
              if (quizQuestion.answerChoices[3] == quizQuestion.correctAnswer) counter++;
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_Java()));
            }else {
              myTimer.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_1()));}
          }),
          const SizedBox(height: 20,),
          My_Counter(counter: counter),
        ],
      ),
    );
  }

}


