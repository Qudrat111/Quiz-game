import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// MyAvatar
class MyAvatar extends StatelessWidget {
  final double radius;
  final String link;
  const MyAvatar({super.key, required this.radius,required this.link});
  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      backgroundImage: AssetImage(link),
      radius: radius,
    );
  }
}
