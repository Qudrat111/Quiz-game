import 'package:flutter/material.dart';

class MyRegistratsion extends StatelessWidget {
  final String label, hint;
  const MyRegistratsion({super.key, required this.label, required this.hint});
  @override
  Widget build(BuildContext context) {
    return TextField(
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
      ),
    );
  }
}