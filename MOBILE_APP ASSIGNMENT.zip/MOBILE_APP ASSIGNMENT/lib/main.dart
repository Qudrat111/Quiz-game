import 'package:flutter/material.dart';
import 'package:flutterlesson7/Avatar.dart';
import 'package:flutterlesson7/Button.dart';
import 'package:flutterlesson7/Quizz.dart';
import 'package:flutterlesson7/Registratsiya.dart';
import 'package:flutterlesson7/Text.dart';


void main(){

  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyPage(),
  ),);
}
class MyPage extends StatelessWidget {
  const MyPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Page"),
        centerTitle: true,
      ),
      body:  Padding(
        padding:  EdgeInsets.all(60.0),
        child: SingleChildScrollView(
    child: Center(
          child: Column(
            children: [
              SizedBox(height: 40.0),
              MyAvatar(link: 'images/pdp.jpg',radius: 70.0),
              SizedBox(height: 40.0),
              MyText(text: "Welcome",size: 40.0,color: Colors.indigoAccent,),
              SizedBox(height: 40.0),
              MyRegistratsion(label: "Log in", hint: "Enter log in"),
              SizedBox(height: 20.0),
              MyRegistratsion(label: "Password",hint: "Enter Password"),
              SizedBox(height: 40.0),
              MyButton(satr: "Next", click: (){
                Navigator.push(context,MaterialPageRoute(builder: (context) =>  const MyQuizz(),),);
              },
              ),
            ],
          ),
    ),
        ),
        ),
      );
  }
}
