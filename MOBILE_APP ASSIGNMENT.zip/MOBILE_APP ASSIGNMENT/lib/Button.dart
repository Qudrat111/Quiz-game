import 'package:flutter/material.dart';

class MyButton extends StatelessWidget{
  final String satr;
  final VoidCallback click;

  const MyButton({super.key, required this.satr, required this.click,});

  @override
  Widget build(BuildContext context) {
return SingleChildScrollView(
    child: Padding(
  padding: const EdgeInsets.all(20),
  child:   SizedBox(
    height: 40,
    width: double.maxFinite,
    child:  ElevatedButton(
        onPressed: click,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.deepPurpleAccent,
          foregroundColor: Colors.white
        ), child: Text(satr, style: const TextStyle(fontSize: 25,)),

    ),
  ),
    ),
);
  }

}