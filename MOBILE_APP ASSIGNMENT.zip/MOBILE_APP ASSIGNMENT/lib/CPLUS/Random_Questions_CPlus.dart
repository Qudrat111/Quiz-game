import 'dart:async';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlesson7/Counter.dart';
import 'package:flutterlesson7/CPLUS/MyResult2.dart';
import 'package:flutterlesson7/Text.dart';
import '../Button.dart';
int counter1 = 0;
int questionIndex1 = 0;

class QuizQuestion1 {
  String question1;
  List<String> answerChoices1;
  String correctAnswer1;

  QuizQuestion1({
    required this.question1,
    required this.answerChoices1,
    required this.correctAnswer1,
  });
}
List<QuizQuestion1> quizQuestions1 = [
  QuizQuestion1(
      question1: "What does C++ stand for?",
      answerChoices1: [
        "Common Programming Language",
        "Central Processing Language",
        "C Plus Plus*",
       "Complex Programming Language"],
      correctAnswer1: "C Plus Plus*"
  ),

  QuizQuestion1(
      question1: "Which of the following is NOT a fundamental data type in C++?",
      answerChoices1: [
        "int",
        "float",
        "string",
        "char*"],
      correctAnswer1:  "string"
  ),

  QuizQuestion1(
      question1: "In C++, what is the symbol for the modulus operator?",
      answerChoices1: ["%","&","#", "*"],
      correctAnswer1: "%"
  ),

  QuizQuestion1(
      question1: "Which keyword is used to declare a function in C++?",
      answerChoices1: [
        "method",
        "func",
        "define",
        "void*"],
      correctAnswer1: "void*"
  ),

  QuizQuestion1(
      question1: "What is the operator used for logical AND in C++?",
      answerChoices1: ["&&","||","&", "*"],
      correctAnswer1:   "&&"
  ),

  QuizQuestion1(
      question1: "What is the purpose of the "'cin'" object in C++?",
      answerChoices1: [
         "Output to the console",
         "Read from a file",
         "Input from the console*",
         "Display a message"],
      correctAnswer1: "Input from the console*"
  ),

  QuizQuestion1(
      question1: "Which C++ keyword is used to dynamically allocate memory on the heap?",
      answerChoices1: [
        "stack",
        "malloc",
        "new*",
       "allocate"],
      correctAnswer1: "new*"
  ),

  QuizQuestion1(
      question1: "What does " 'const' " signify in C++ when applied to a variable?",
      answerChoices1: [
        "The variable cannot be changed after initialization*",
        "The variable can only be used in constant expressions",
        "The variable can be accessed from any scope",
        "The variable is constantly updated"],
      correctAnswer1: "The variable cannot be changed after initialization*"
  ),

  QuizQuestion1(
      question1: "What is the primary purpose of the " 'break' " statement in C++?",
      answerChoices1: [
         "To terminate the program",
         "To skip the current iteration of a loop*",
         "To continue to the next iteration of a loop",
         "To exit a function"],
      correctAnswer1: "To skip the current iteration of a loop*"
  ),
  QuizQuestion1(
      question1: "Which standard C++ library header is used for input and output operations?",
      answerChoices1: [
        "<math.h>",
       "<stdio.h>",
      "<iostream>*",
      "<fstream.h>]"],
      correctAnswer1: "<iostream>*"
  ),

];

class My_Savollar_Logikasi_CPlus extends StatelessWidget{
  const My_Savollar_Logikasi_CPlus({super.key});
  @override
  Widget build(BuildContext context) {
    Timer myTimer1 = Timer(const Duration(seconds: 20), (){
      Navigator.push(context,MaterialPageRoute(builder: (context) =>  const My_Savollar_Logikasi_CPlus()));
    });
    Random random = Random();
    QuizQuestion1 quizQuestion1 = quizQuestions1[random.nextInt(quizQuestions1.length)];
    quizQuestions1.remove(quizQuestion1);
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        children:[
          MyText(text: "Savol ${++questionIndex1} :${quizQuestion1.question1}", size: 30.0,color: Colors.blue),
          const SizedBox(height: 40,),
          MyButton(satr: quizQuestion1.answerChoices1[0],click: (){
            if(quizQuestions1.isNotEmpty) {
              if (quizQuestion1.answerChoices1[0] == quizQuestion1.correctAnswer1) counter1++;
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_CPlus()));
            }else {
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_2()));
            }
          }),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion1.answerChoices1[1], click:(){
            if(quizQuestions1.isNotEmpty) {
              if (quizQuestion1.answerChoices1[1] == quizQuestion1.correctAnswer1) counter1++;
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Savollar_Logikasi_CPlus()));
            }else {
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_2()));}
          }),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion1.answerChoices1[2],click:(){
            if(quizQuestions1.isNotEmpty) {
              if (quizQuestion1.answerChoices1[2] == quizQuestion1.correctAnswer1) counter1++;
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_CPlus()));
            }else {
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_2()));}
          },),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion1.answerChoices1[3],click: (){
            if(quizQuestions1.isNotEmpty) {
              if (quizQuestion1.answerChoices1[3] == quizQuestion1.correctAnswer1) counter1++;
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_CPlus()));
            }else {
              myTimer1.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_2()));}
          }),
          const SizedBox(height: 20,),
          My_Counter(counter: counter1),
        ],
      ),
    );
  }

}


