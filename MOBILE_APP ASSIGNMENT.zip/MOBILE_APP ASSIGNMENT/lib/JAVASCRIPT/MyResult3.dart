import 'package:flutter/material.dart';
import 'package:flutterlesson7/Button.dart';
import 'JavaScript.dart';
import '../main.dart';


class My_Result_3 extends StatelessWidget{
  const My_Result_3({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            Text("Siz 10 tadan ${counter2} ta to'g'ri javob topdingiz",
              style: const TextStyle(fontSize: 45,color: Colors.blue),
            ),
            MyButton(satr: "YANA O'YNASHNI HOHLAYSIZMI", click: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) =>  const MyPage()));
            })
          ],
        ),
      ),
    );
  }
}