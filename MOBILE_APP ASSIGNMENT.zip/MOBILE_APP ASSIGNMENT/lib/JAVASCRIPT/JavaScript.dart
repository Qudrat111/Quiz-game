import 'dart:async';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlesson7/Counter.dart';
import 'package:flutterlesson7/JAVASCRIPT/MyResult3.dart';
import 'package:flutterlesson7/Text.dart';
import '../Button.dart';
int counter2 = 0;
int questionIndex2 = 0;

class QuizQuestion2 {
  String question2;
  List<String> answerChoices2;
  String correctAnswer2;

  QuizQuestion2({
    required this.question2,
    required this.answerChoices2,
    required this.correctAnswer2,
  });
}

List<QuizQuestion2> quizQuestions2 = [
  QuizQuestion2(
      question2: "What keyword is used to declare a variable in JavaScript?",
      answerChoices2: ["var", "let","const", "variable"],
      correctAnswer2: "var"
  ),

  QuizQuestion2(
      question2: " Which of the following is NOT a primitive data type in JavaScript?",
      answerChoices2: [
        "string",
        "object",
       "boolean",
        "number"],
      correctAnswer2: "object"
  ),

  QuizQuestion2(
      question2: " What is the purpose of the typeof operator in JavaScript?",
      answerChoices2: [
        "To check if a variable is defined",
        "To determine the type of a value or variable",
        "To convert a value to a boolean",
        "To create a new variable"],
      correctAnswer2: "To determine the type of a value or variable"
  ),

  QuizQuestion2(
      question2: "Which function is used to add an element to the end of an array in JavaScript?",
      answerChoices2: [
        "push()",
        "add()",
        "append()",
       "insert()"],
      correctAnswer2: "push()"
  ),

  QuizQuestion2(
      question2: "What is the result of 3 + '3' in JavaScript?",
      answerChoices2: ["33","6"," '33' ", "Error"],
      correctAnswer2:   " '33' "
  ),

  QuizQuestion2(
      question2: "Which loop in JavaScript is used for iterating over the properties of an object?",
      answerChoices2: [
        "for-in loop",
        "for-of loop",
        "while loop",
        "do-while loop"],
      correctAnswer2:  "for-in loop"
  ),

  QuizQuestion2(
      question2: "How do you comment out multiple lines of code in JavaScript?",
      answerChoices2: [
     "// This is a comment",
     "/* This is a comment */",
      "<!-- This is a comment -->",
   "  ''' This is a comment '''  "],
      correctAnswer2: "/* This is a comment */"
  ),

  QuizQuestion2(
      question2: "Which method is used to remove the last element from an array in JavaScript?",
      answerChoices2: [
      "remove()",
       "pop()",
       "delete()",
       "splice()"],
      correctAnswer2: "pop()"
  ),

  QuizQuestion2(
      question2: "Which operator is used for strict equality in JavaScript?",
      answerChoices2: ["==","===","=","!="],
      correctAnswer2: "==="
  ),
  QuizQuestion2(
      question2: "What is the purpose of the JSON.parse() function in JavaScript?",
      answerChoices2: [
      "To stringify a JavaScript object",
      "To convert a JSON string into a JavaScript object",
      "To remove elements from an array",
      "To create a new JavaScript object"],
      correctAnswer2: "To convert a JSON string into a JavaScript object"
  ),

];

class My_Savollar_Logikasi_JavaScript extends StatelessWidget{
  const My_Savollar_Logikasi_JavaScript({super.key});
  @override
  Widget build(BuildContext context) {
    Timer myTimer2 = Timer(const Duration(seconds: 20), (){
      Navigator.push(context,MaterialPageRoute(builder: (context) =>  const My_Savollar_Logikasi_JavaScript()));
    });
    Random random = Random();
    QuizQuestion2 quizQuestion2 = quizQuestions2[random.nextInt(quizQuestions2.length)];
    quizQuestions2.remove(quizQuestion2);
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        children:[
          MyText(text: "Savol ${++questionIndex2} :${quizQuestion2.question2}", size: 30.0,color: Colors.blue),
          const SizedBox(height: 40,),
          MyButton(satr: quizQuestion2.answerChoices2[0],click: (){
            if(quizQuestions2.isNotEmpty) {
              if (quizQuestion2.answerChoices2[0] == quizQuestion2.correctAnswer2) counter2++;
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_JavaScript()));
            }else {
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_3()));}
          }),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion2.answerChoices2[1], click:(){
            if(quizQuestions2.isNotEmpty) {
              if (quizQuestion2.answerChoices2[1] == quizQuestion2.correctAnswer2) counter2++;
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Savollar_Logikasi_JavaScript()));
            }else {
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_3()));}
          }),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion2.answerChoices2[2],click:(){
            if(quizQuestions2.isNotEmpty) {
              if (quizQuestion2.answerChoices2[2] == quizQuestion2.correctAnswer2) counter2++;
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_JavaScript()));
            }else {
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) =>const My_Result_3()));}
          },),
          const SizedBox(height: 30,),
          MyButton(satr: quizQuestion2.answerChoices2[3],click: (){
            if(quizQuestions2.isNotEmpty) {
              if (quizQuestion2.answerChoices2[3] == quizQuestion2.correctAnswer2) counter2++;
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => My_Savollar_Logikasi_JavaScript()));
            }else {
              myTimer2.cancel();
              Navigator.push(context, MaterialPageRoute(builder: (context) => const My_Result_3()));}
          }),
          const SizedBox(height: 20,),
          My_Counter(counter: counter2),
        ],
      ),
    );
  }

}