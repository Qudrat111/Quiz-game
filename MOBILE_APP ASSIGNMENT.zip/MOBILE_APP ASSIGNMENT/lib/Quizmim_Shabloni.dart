import 'package:flutter/material.dart';
import 'package:flutterlesson7/Button.dart';
import 'package:flutterlesson7/CPLUS/Random_Questions_CPlus.dart';
import 'package:flutterlesson7/JAVASCRIPT/JavaScript.dart';
import 'package:flutterlesson7/Text.dart';
import 'JAVA/Random_Java_Questions.dart';

class My_Quizim_Shabloni extends StatelessWidget{
  final String savol,sub_1,sub_2,sub_3;
  const My_Quizim_Shabloni({super.key, required this.savol, required this.sub_1, required this.sub_2, required this.sub_3});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        children:[
        MyText(text: savol, size: 50.0,color: Colors.blue),
          const SizedBox(height: 40.0,),
        MyButton(satr: sub_1,click: (){Navigator.push(context,MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_Java()));}),
        const SizedBox(height: 40.0,),
        MyButton(satr: sub_2,click: (){Navigator.push(context,MaterialPageRoute(builder: (context) => const My_Savollar_Logikasi_CPlus()));}),
         const SizedBox(height: 40.0,),
        MyButton(satr: sub_3,click: (){Navigator.push(context,MaterialPageRoute(builder: (context) =>  const My_Savollar_Logikasi_JavaScript()));}),
      ],
      ),
      );
  }
}