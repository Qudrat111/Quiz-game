import 'package:flutter/cupertino.dart';
import 'package:flutterlesson7/Text.dart';

class My_Counter extends StatelessWidget{
  String str = "wldecjdh";
   int counter;
   My_Counter({super.key, required this.counter});

  @override
  Widget build(BuildContext context) {
    return   Padding(
      padding: EdgeInsets.all(20.0),
      child: Center(
        child: MyText(text: "Real vaqtdagi to'g'ri javoblar soni  ${counter} ta",size: 25,color: CupertinoColors.destructiveRed,)
      ),
    );
  }

}
