import 'package:flutter/material.dart';
import 'package:flutterlesson7/Quizmim_Shabloni.dart';

class MyQuizz extends StatelessWidget{
  const MyQuizz({super.key});

  @override
  Widget build(BuildContext context) {
    String t = "Mening quizim";
   return Scaffold(
     appBar: AppBar(title:Text(t),centerTitle: true),
     body: Container(
       child: My_Quizim_Shabloni(
          savol: "Qaysi fandan quiz ishlashni hohlaysiz",
          sub_1: "Java dasturlash tili",
          sub_2: "C++ dasturlash tili",
          sub_3: "J_script dasturlash tili"),
     ),
   );
  }
}
